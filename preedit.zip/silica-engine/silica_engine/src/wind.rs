use serde::{Deserialize, Serialize};

/// Represents wind forces in the simulation
#[derive(Clone, Copy, Debug, PartialEq, Serialize, Deserialize)]
pub struct Wind {
    /// Horizontal wind force component
    pub dx: i8,
    /// Vertical wind force component
    pub dy: i8,
    /// Pressure at this position
    pub pressure: f32,
    /// Density at this position
    pub density: f32,
}

impl Default for Wind {
    fn default() -> Self {
        Self {
            dx: 0,
            dy: 0,
            pressure: 0.0,
            density: 0.0,
        }
    }
}

impl Wind {
    /// Creates a new wind instance with the given directional forces
    pub fn new(dx: i8, dy: i8, pressure: f32, density: f32) -> Self {
        Self {
            dx,
            dy,
            pressure,
            density,
        }
    }
    
    /// Calculates the wind strength based on dx and dy components
    pub fn strength(&self) -> f32 {
        ((self.dx as f32).powi(2) + (self.dy as f32).powi(2)).sqrt()
    }
    
    /// Increases wind in a given direction (used by wind generators)
    pub fn add_force(&mut self, dx: i8, dy: i8) {
        // Cap the values to prevent excessive wind speeds
        self.dx = (self.dx as i16 + dx as i16).clamp(-100, 100) as i8;
        self.dy = (self.dy as i16 + dy as i16).clamp(-100, 100) as i8;
    }
    
    /// Gradually reduces wind forces to simulate friction and dissipation
    pub fn decay(&mut self, decay_rate: f32) {
        if self.dx != 0 {
            self.dx = (self.dx as f32 * (1.0 - decay_rate)) as i8;
        }
        if self.dy != 0 {
            self.dy = (self.dy as f32 * (1.0 - decay_rate)) as i8;
        }
    }
}
