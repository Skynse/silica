use crate::{
    particle,
    prelude::{Particle, Variant, Wind, World, API, EMPTY_CELL},
};

// The point of chunks is to not process a chunk if
// particles in it haven't changed since the last tick.
#[derive(Clone)]
pub struct Chunk {
    pub particles: Vec<Particle>,
    pub wind: Vec<Wind>,
    pub dirty: bool,
    pub width: i32,
    pub height: i32,
}

impl Chunk {
    pub fn new(chunk_width: i32, chunk_height: i32) -> Self {
        let mut particles = Vec::new();
        let mut wind = Vec::new();

        // Iterate over each cell in the chunk
        for _ in 0..chunk_width {
            for _ in 0..chunk_height {
                particles.push(EMPTY_CELL);
                wind.push(Wind {
                    dx: 0,
                    dy: 0,
                    pressure: 0,
                    density: 0,
                });
            }
        }

        Self {
            particles,
            wind,
            dirty: false,
            width: chunk_width,
            height: chunk_height,
        }
    }

    pub fn update(&mut self, world: &mut World) {
        if self.dirty {
            for x in 0..self.width {
                for y in 0..self.height {
                    let particle = self.get_particle(x as i32, y as i32);
                    let wind = self.get_wind(x as i32, y as i32);
                    World::blow_wind(
                        particle,
                        wind,
                        API {
                            x: x as i32,
                            y: y as i32,
                            chunk: self,
                            world,
                        },
                    );

                    Chunk::update_particle(
                        particle,
                        API {
                            x: x as i32,
                            y: y as i32,
                            chunk: self,
                            world,
                        },
                    );
                }
            }
            self.dirty = false;
        }
    }

    pub fn get_wind(&self, x: i32, y: i32) -> Wind {
        let idx = self.get_idx(x, y);
        self.wind[idx]
    }

    pub fn get_particle(&self, x: i32, y: i32) -> Particle {
        let idx = self.get_idx(x, y);
        self.particles[idx]
    }

    pub fn update_particle(particle: Particle, api: API) {
        // Your existing logic for updating particles
        particle.variant.update(particle, api);
    }

    pub fn set(&mut self, x: i32, y: i32, particle: Particle) {
        let idx = self.get_idx(x, y);
        self.particles[idx] = particle;
        self.dirty = true;
    }    fn blow_wind(mut particle: Particle, wind: Wind, mut api: API) {
        // Skip empty particles and immovable objects
        if particle.variant_type.variant == Variant::Empty || 
           (particle.variant_type.flags & variant_type::FLAG_IMMUTABLE) != 0 {
            return;
        }
        
        // Apply wind force to particle velocity based on particle traits
        let weight = particle.variant_type.weight;
        
        // Lighter particles are affected more by wind
        let wind_influence = if weight > 0.0 { 1.0 / weight } else { 1.0 };
        
        // Multiply by a small factor to control wind intensity
        let wind_factor = 0.05;
        
        // Update particle velocity based on wind direction and strength
        let wind_force_x = wind.dx as f32 * wind_influence * wind_factor;
        let wind_force_y = wind.dy as f32 * wind_influence * wind_factor;
        
        particle.velocity.x += wind_force_x;
        particle.velocity.y += wind_force_y;
        
        // Apply velocity limits to prevent excessive speeds
        let max_velocity = 5.0;
        particle.velocity.x = particle.velocity.x.clamp(-max_velocity, max_velocity);
        particle.velocity.y = particle.velocity.y.clamp(-max_velocity, max_velocity);
        
        // Update the particle in the world
        if wind.dx != 0 || wind.dy != 0 {
            api.set(0, 0, particle);
        }
    }

    pub fn get_idx(&self, x: i32, y: i32) -> usize {
        // get index of particle in chunk assuming 2d
        (y * self.width + x) as usize
    }
}
