use std::{
    collections::HashSet,
    io::{BufWriter, Read, Write},
    path::Path,
};

use crate::{
    api::API,
    particle::{self, Particle},
    variant::Variant,
    variant_type,
    wind::Wind,
};

use serde::{Deserialize, Serialize};
use std::fs::File;
use variant_type::{VariantProperty, VariantType, EMPTY, FLAG_ALIVE};

pub const GRAVITY: f32 = 10f32;
pub const SPREAD_FACTOR: f32 = 0.1f32;

#[derive(Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Environment {
    pub pressure: f32,
    pub ambient_temperature: f32,
    pub ambient_pressure: f32,
}
#[derive(Serialize, Deserialize)]
pub struct World {
    pub(crate) particles: Vec<Particle>,
    pub environment: Vec<Environment>,
    pub(crate) wind: Vec<Wind>,
    pub width: i32,
    pub height: i32,
    pub running: bool,
    pub generation: u8,
    pub modified_indices: HashSet<usize>,
    pub cleared: bool,
    pub modified_state: bool,
}

impl Default for World {
    fn default() -> Self {
        Self::new(256, 256)
    }
}

impl World {
    pub fn save_to_slc(&mut self, path: &str) {
        let mut p = String::from(path);

        // add slc extension if not present
        if !p.ends_with(".slc") {
            p.push_str(".slc");
        }

        let mut encoder = brotli::CompressorWriter::new(File::create(p).unwrap(), 4096, 11, 22);
        let mut buf = vec![];
        // serialize the entire world
        buf.extend_from_slice(&bincode::serialize(self).unwrap());

        encoder.write_all(buf.as_mut()).unwrap();
        encoder.flush().unwrap();

        println!("saving to {}.slc", path);
    }

    pub fn load_from_slc(&mut self, path: &str) {
        println!("loaded from {}", path);
        let mut decoder = brotli::Decompressor::new(File::open(path).unwrap(), 4096);
        let mut buf = vec![];
        decoder.read_to_end(buf.as_mut()).unwrap();

        let world: World = bincode::deserialize(&buf).unwrap();
        *self = world;
    }
    pub fn save(&self, path: &str) {
        let mut p = String::from(path);

        let mut image = Vec::new();
        for particle in self.particles.iter() {
            let color = particle::particle_to_color(*particle).to_rgb8();
            image.push(color.0);
            image.push(color.1);
            image.push(color.2);
        }

        // add png extension if not present
        if !p.ends_with(".png") {
            p.push_str(".png");
        }

        let ref mut w = BufWriter::new(File::create(p).unwrap());
        let mut encoder = png::Encoder::new(w, self.width as u32, self.height as u32);
        encoder.set_color(png::ColorType::Rgb);
        encoder.set_depth(png::BitDepth::Eight);
        let mut writer = encoder.write_header().unwrap();
        writer.write_image_data(&image).unwrap(); // Save
        println!("saving to {}.png", path);
    }

    pub fn load(&mut self, path: &str) {
        println!("loaded from {}", path);
        let decoder = png::Decoder::new(File::open(path).unwrap());
        let mut reader = decoder.read_info().unwrap();
        let mut buf = vec![0; reader.output_buffer_size()];
        reader.next_frame(&mut buf).unwrap();

        let mut i = 0;
        for y in 0..self.height {
            for x in 0..self.width {
                let idx = self.get_idx(x, y);
                let r = buf[i];
                let g = buf[i + 1];
                let b = buf[i + 2];
                self.particles[idx] = particle::color_to_particle((r, g, b));
                i += 3;
            }
        }
    }
    pub fn tick(&mut self) {
        self.cleared = false;
        if self.running {
            // First process wind propagation through the world
            self.propagate_wind();

            // Apply wind effects to particles
            for x in 0..self.width {
                for y in 0..self.height {
                    let particle = self.get_particle(x as i32, y as i32);
                    let wind = self.get_wind(x as i32, y as i32);
                    Self::blow_wind(
                        particle,
                        wind,
                        API {
                            world: self,
                            x: x as i32,
                            y: y as i32,
                        },
                    );
                }
            }
            //  self.generation = self.generation.wrapping_add(1);
            /*
            for x in 0..self.width {
                let scanx = if self.generation % 2 == 0 {
                    self.width - (x + 1)
                } else {
                    x
                };
                for y in 0..self.height {
                    let idx = self.get_idx(scanx as i32, y as i32);
                    let particle = self.get_particle(scanx as i32, y as i32);
                    World::update_particle(
                        particle,
                        API {
                            world: self,
                            x: scanx as i32,
                            y: y as i32,
                        },
                    );
                }
            }
            */

            // take iterator instead

            // iterate in reverse order
            for x in (0..self.width).rev() {
                let scanx = if self.generation % 2 == 0 {
                    self.width - (x + 1)
                } else {
                    x
                };
                for y in (0..self.height).rev() {
                    let idx = self.get_idx(scanx as i32, y as i32);

                    let particle = self.get_particle(scanx as i32, y as i32);
                    if particle.modified {
                        self.modified_indices.insert(idx);
                        continue;
                    }

                    // self.distribute_cell_temperature(x, y);

                    self.modified_state = World::update_particle(
                        particle,
                        API {
                            world: self,
                            x: scanx as i32,
                            y: y as i32,
                        },
                    );
                    if self.modified_state {
                        self.modified_indices.insert(idx);
                    }
                } //end gen
            }

            // ambient heat calculation
            // take a 3x3 grid and share temp based on center temp until all cells are the same

            self.generation = self.generation.wrapping_add(1);
            self.modified_indices.clear();
        }
    }

    pub fn needs_update(&self) -> bool {
        self.cleared || !self.modified_indices.is_empty()
    }

    pub fn pause(&mut self) {
        self.running = false;
    }

    pub fn resume(&mut self) {
        self.running = true;
    }

    fn update_particle(mut particle: Particle, mut api: API) -> bool {
        if particle.modified {
            return false;
        }

        if particle.get_variant() == Variant::Empty && !particle.variant_type.has_flag(FLAG_ALIVE) {
            return false;
        }

        if particle.variant_type.has_flag(variant_type::FLAG_IMMUTABLE) {
            return false;
        }

        // decrease temperature over time to variant base temperature
        let temperature = particle.temperature;
        let base_temperature = particle.variant_type.base_temperature;
        let temperature_decay_rate = 0.01; // Adjust this rate based on your preference

        particle.temperature += (base_temperature - temperature) * temperature_decay_rate;
        let _type = particle.variant_type;
        match particle.variant_type.variant_property {
            VariantProperty::Powder => {
                let dx = api.rand_dir();
                let nbr = api.get(0, 1);

                if nbr.get_variant() == Variant::Empty {
                    api.set(dx, 1, particle);
                    api.set(0, 0, Particle::default());
                } else if api.get(dx, 1).get_variant() == Variant::Empty {
                    api.set(dx, 1, particle);
                    api.set(0, 0, Particle::default());
                } else if nbr.variant_type.variant_property == VariantProperty::Liquid {
                    api.set(0, 0, nbr);
                    api.set(0, 1, particle);
                } else {
                    let weight_diff = particle
                        .variant_type
                        .weight
                        .wrapping_sub(nbr.variant_type.weight);
                    let max_velocity = 5;
                    let velocity = weight_diff.min(max_velocity);

                    for _ in 0..velocity {
                        if api.get(0, 1).get_variant() == Variant::Empty {
                            api.set(0, 1, particle);
                            api.set(0, 0, Particle::default());
                            break;
                        } else if api.get(dx, 1).get_variant() == Variant::Empty {
                            api.set(dx, 1, particle);
                            api.set(0, 0, Particle::default());
                            break;
                        } else if api.get(0, 1).variant_type.variant_property
                            == VariantProperty::Liquid
                        {
                            api.set(0, 0, nbr);
                            api.set(0, 1, particle);
                            break;
                        } else {
                            api.set(0, 0, particle);
                            break;
                        }
                    }
                }
            }

            VariantProperty::Liquid => {
                let mut dx = api.rand_dir();
                let below = api.get(0, 1);
                let dx1 = api.get(dx, 1);
                if particle.variant_type.weight > below.variant_type.weight {
                    //swap
                    api.swap(0, 1);
                }

                // let mut dx0 = api.get(dx, 0);
                //fall down
                if below.get_variant() == Variant::Empty {
                    api.set(0, 0, below);
                    let mut ra = particle.ra;
                    if api.once_in(20) {
                        //randomize direction when falling sometimes
                        ra = 100 + api.rand_int(50) as u8;
                    }
                    api.set(0, 1, Particle { ra, ..particle });

                    return true;
                } else if dx1.get_variant() == Variant::Empty {
                    //fall diagonally
                    api.set(0, 0, dx1);
                    api.set(dx, 1, particle);
                    return true;
                } else if api.get(-dx, 1).get_variant() == Variant::Empty {
                    api.set(0, 0, Particle::default());
                    api.set(-dx, 1, particle);
                    return true;
                }
                let left = particle.ra % 2 == 0;
                dx = if left { 1 } else { -1 };
                let dx0 = api.get(dx, 0);
                let dxd = api.get(dx * 2, 0);

                if dx0.get_variant() == Variant::Empty && dxd.get_variant() == Variant::Empty {
                    // scoot double
                    api.set(0, 0, dxd);
                    api.set(2 * dx, 0, Particle { rb: 6, ..particle });
                    let (dx, dy) = api.rand_vec(); //rand_vec_8
                    let nbr = api.get(dx, dy);

                    // spread opinion
                    if nbr.get_variant() == Variant::Water && nbr.ra % 2 != particle.ra % 2 {
                        api.set(
                            dx,
                            dy,
                            Particle {
                                ra: particle.ra,
                                ..particle
                            },
                        )
                    }
                } else if dx0.get_variant() == Variant::Empty {
                    api.set(0, 0, dx0);
                    api.set(dx, 0, Particle { rb: 3, ..particle });
                    let (dx, dy) = api.rand_vec(); //rand_vec_8
                    let nbr = api.get(dx, dy);
                    if nbr.get_variant() == Variant::Water {
                        if nbr.ra % 2 != particle.ra % 2 {
                            api.set(
                                dx,
                                dy,
                                Particle {
                                    ra: particle.ra,
                                    ..particle
                                },
                            )
                        }
                    }
                } else if particle.rb == 0 {
                    if api.get(-dx, 0).get_variant() == Variant::Empty {
                        // bump
                        api.set(
                            0,
                            0,
                            Particle {
                                ra: ((particle.ra as i32) + dx) as u8,
                                ..particle
                            },
                        );
                    }
                } else {
                    // become less certain (more bumpable)
                    api.set(
                        0,
                        0,
                        Particle {
                            rb: particle.rb - 1,
                            ..particle
                        },
                    );
                }

                // weight distribution
                let dx = api.rand_dir();
                let nbr = api.get(dx, 1);
                let weight = particle.variant_type.weight;
                let nbr_weight = nbr.variant_type.weight;

                if nbr_weight < weight {
                    // swap
                    api.swap(0, 1);
                }
            }

            VariantProperty::Gas => {
                // basic sand behavior but upwards
                let dx = api.rand_dir();
                let nbr = api.get(dx, -1);

                if api.get(dx, -1).get_variant() == Variant::Empty {
                    api.set(dx, -1, particle);
                    api.set(0, 0, Particle::default());
                } else {
                    api.set(0, 0, particle);
                }
            }
            // spread opinion
            _ => (),
        }
        let state = &particle.update(api);
        particle.modified = *state;
        *state
    }

    fn paint_variants(&mut self) {
        for x in 0..self.width {
            for y in 0..self.height {
                let idx = self.get_idx(x, y);
                let particle = self.get_particle(x, y);
                let _variant = particle.get_variant();
                let color = particle::particle_to_color(particle).to_rgba8();
                self.particles[idx].ra = color.0;
                self.particles[idx].rb = color.1;
                self.particles[idx].clock = self.generation;
            }
        }
    }
    pub fn new(width: i32, height: i32) -> World {
        let particles = (0..width * height).map(|_| Particle::default()).collect();
        let environment: Vec<Environment> = (0..width * height)
            .map(|_| Environment {
                pressure: 0.,
                ambient_temperature: 22.,
                ambient_pressure: 0.,
            })
            .collect();
        let wind: Vec<Wind> = (0..width * height).map(|_| Wind::default()).collect();
        World {
            particles,
            environment,
            wind,
            width: width,
            height: height,
            running: true,
            generation: 0,
            modified_indices: HashSet::new(),
            cleared: false,
            modified_state: false,
        }
    }

    pub fn particles(&self) -> *const Particle {
        self.particles.as_ptr()
    }

    pub fn reset(&mut self) {
        for particle in self.particles.iter_mut() {
            *particle = Particle::new(EMPTY, 0, 0);
        }

        self.cleared = true;
        self.modified_indices.clear();
    }

    // Get the wind at a specific position
    pub fn get_wind(&self, x: i32, y: i32) -> Wind {
        let idx = self.get_idx(x, y);
        self.wind[idx]
    }

    // Set wind value at a specific position
    pub fn set_wind(&mut self, x: i32, y: i32, value: Wind) {
        let idx = self.get_idx(x, y);
        self.wind[idx] = value;
    }

    // Add wind force at a specific position
    pub fn add_wind(&mut self, x: i32, y: i32, dx: i8, dy: i8) {
        let mut wind = self.get_wind(x, y);
        wind.add_force(dx, dy);
        self.set_wind(x, y, wind);
    } // Propagate wind to nearby cells
    fn propagate_wind(&mut self) {
        let width = self.width;
        let height = self.height; // Create a temporary copy of the wind field
        let wind_copy = self.wind.clone(); // Propagation factor determines how much wind spreads to neighboring cells
        let propagation_factor = 0.48; // Further increased for even better spread to neighboring cells

        // Wind friction factor makes wind decrease over time (lower value means wind persists longer)
        let friction_factor = 0.004; // Further reduced to make wind persist even longer

        for x in 1..width - 1 {
            for y in 1..height - 1 {
                let idx = self.get_idx(x, y);
                let current_wind = wind_copy[idx];

                // Apply friction to reduce wind strength over time
                let mut new_wind = current_wind;
                new_wind.decay(friction_factor);

                // If there's any wind force, propagate it to neighbors
                if current_wind.dx != 0 || current_wind.dy != 0 {
                    // Directions the wind will propagate to - prioritize the main wind direction
                    // This makes wind flow more naturally in its primary direction
                    let primary_dir_x = if current_wind.dx > 0 {
                        1
                    } else if current_wind.dx < 0 {
                        -1
                    } else {
                        0
                    };
                    let primary_dir_y = if current_wind.dy > 0 {
                        1
                    } else if current_wind.dy < 0 {
                        -1
                    } else {
                        0
                    };

                    // Primary direction gets more propagation
                    if primary_dir_x != 0 || primary_dir_y != 0 {
                        let nx = x as i32 + primary_dir_x;
                        let ny = y as i32 + primary_dir_y;

                        if nx >= 0 && nx < width && ny >= 0 && ny < height {
                            // Calculate the amount of wind to propagate - more in primary direction
                            let prop_dx = (current_wind.dx as f32 * 0.85) as i8; // 85% in primary direction (increased from 70%)
                            let prop_dy = (current_wind.dy as f32 * 0.85) as i8;

                            if prop_dx != 0 || prop_dy != 0 {
                                let mut neighbor_wind = self.get_wind(nx, ny);
                                neighbor_wind.add_force(prop_dx, prop_dy);
                                self.set_wind(nx, ny, neighbor_wind);
                            }
                        }
                    }

                    // Secondary directions get less propagation
                    let secondary_dirs = [
                        (x as i32 + 1, y as i32),
                        (x as i32 - 1, y as i32),
                        (x as i32, y as i32 + 1),
                        (x as i32, y as i32 - 1),
                    ];

                    for (nx, ny) in secondary_dirs.iter() {
                        // Skip primary direction as it's already handled
                        if *nx == x as i32 + primary_dir_x && *ny == y as i32 + primary_dir_y {
                            continue;
                        }

                        if *nx >= 0 && *nx < width && *ny >= 0 && *ny < height {
                            // Less propagation in secondary directions
                            let prop_dx = (current_wind.dx as f32 * propagation_factor) as i8;
                            let prop_dy = (current_wind.dy as f32 * propagation_factor) as i8;

                            if prop_dx != 0 || prop_dy != 0 {
                                let mut neighbor_wind = self.get_wind(*nx, *ny);
                                neighbor_wind.add_force(prop_dx, prop_dy);
                                self.set_wind(*nx, *ny, neighbor_wind);
                            }
                        }
                    }
                }

                // Update the current cell's wind                self.wind[idx] = new_wind;
            }
        }
    }

    // Apply wind effects to a particle
    fn blow_wind(mut particle: Particle, wind: Wind, mut api: API) {
        // Skip empty particles and immovable objects
        if particle.variant_type.source_variant == Variant::Empty
            || (particle.variant_type.flags & variant_type::FLAG_IMMUTABLE) != 0
        {
            return;
        }

        // Only apply wind if there's actual wind force
        if wind.dx == 0 && wind.dy == 0 {
            return;
        } // Apply wind force to particle velocity based on particle traits
        let weight = particle.variant_type.weight;

        // Lighter particles are affected more by wind
        let weight_as_float = weight as f32;
        let wind_influence = if weight_as_float > 0.0 {
            1.0 / weight_as_float.powf(0.5) // Reduce the power for stronger effect on medium weight particles
        } else {
            1.0
        }; // Multiply by a factor to control wind intensity
        let wind_factor = 0.8; // Significantly increased from 0.3 for much stronger wind effect

        // Calculate wind strength to scale the effect
        let wind_strength = wind.strength();
        let strength_multiplier = (1.0 + wind_strength * 0.1).min(2.0); // Wind gets stronger as it accumulates

        // Update particle velocity based on wind direction and strength
        let wind_force_x = wind.dx as f32 * wind_influence * wind_factor * strength_multiplier;
        let wind_force_y = wind.dy as f32 * wind_influence * wind_factor * strength_multiplier;
        particle.velocity.x += wind_force_x;
        particle.velocity.y += wind_force_y;

        // Apply velocity limits to prevent excessive speeds - scale with wind strength for stronger effects
        let wind_strength = wind.strength();
        let max_velocity = 5.0 + (wind_strength * 0.6).min(3.0); // Allow higher velocities in strong winds
        particle.velocity.x = particle.velocity.x.clamp(-max_velocity, max_velocity);
        particle.velocity.y = particle.velocity.y.clamp(-max_velocity, max_velocity);

        // Update the particle in the world so it starts moving
        api.set(0, 0, particle);
    }

    // Generate a directional wind across a region of the world
    // Can be used for windstorms or other wind-generating events
    pub fn generate_directional_wind(
        &mut self,
        x_start: i32,
        y_start: i32,
        width: i32,
        height: i32,
        dx: i8,
        dy: i8,
        strength: f32,
    ) {
        let x_end = (x_start + width).min(self.width as i32);
        let y_end = (y_start + height).min(self.height as i32);

        let x_start = x_start.max(0);
        let y_start = y_start.max(0);

        for x in x_start..x_end {
            for y in y_start..y_end {
                // Calculate distance from center for a more natural wind distribution
                let center_x = x_start + width / 2;
                let center_y = y_start + height / 2;
                let dist_x = (x - center_x) as f32;
                let dist_y = (y - center_y) as f32;
                let distance = (dist_x * dist_x + dist_y * dist_y).sqrt();
                let radius = (width.min(height) / 2) as f32;

                // Create a gradual falloff from center for a more natural wind pattern
                let falloff = 1.0 - (distance / radius).min(1.0) * 0.5;

                // Scale the wind strength with falloff and apply the strength parameter
                let wind_dx = (dx as f32 * strength * falloff) as i8;
                let wind_dy = (dy as f32 * strength * falloff) as i8;

                // Add wind to this position
                self.add_wind(x, y, wind_dx, wind_dy);
            }
        }
    }
}

impl World {
    pub fn get_idx(&self, x: i32, y: i32) -> usize {
        if x < 0 || x > self.width - 1 || y < 0 || y > self.height - 1 {
            return 0;
        }
        (x + y * self.width) as usize
    }

    pub fn get_temperature(&self, x: i32, y: i32) -> f32 {
        let idx = self.get_idx(x, y);
        self.environment[idx].ambient_temperature
    }

    pub fn distribute_cell_temperature(&mut self, x: i32, y: i32) {
        let center_temp = self.get_temperature(x, y);
        let heat = center_temp / 4.;

        // Get and update each neighboring particle
        if x >= 0 && y >= 0 && x < self.width && y < self.height {
            let idx = self.get_idx(x, y);
            let mut top = self.particles[idx];
            top.temperature += heat;
            self.particles[idx] = top;
        }

        if x >= 0 && y + 1 >= 0 && x < self.width && y + 1 < self.height {
            let idx = self.get_idx(x, y + 1);
            let mut bottom = self.particles[idx];
            bottom.temperature += heat;
            self.particles[idx] = bottom;
        }

        if x - 1 >= 0 && y >= 0 && x - 1 < self.width && y < self.height {
            let idx = self.get_idx(x - 1, y);
            let mut left = self.particles[idx];
            left.temperature += heat;
            self.particles[idx] = left;
        }

        if x + 1 >= 0 && y >= 0 && x + 1 < self.width && y < self.height {
            let idx = self.get_idx(x + 1, y);
            let mut right = self.particles[idx];
            right.temperature += heat;
            self.particles[idx] = right;
        }
    }

    pub fn get_pressure(&self, x: i32, y: i32) -> f32 {
        let idx = self.get_idx(x, y);
        self.environment[idx].ambient_pressure
    }

    pub fn get_particle(&self, x: i32, y: i32) -> Particle {
        if x < 0 || x > self.width - 1 || y < 0 || y > self.height - 1 {
            return Particle::default();
        }
        let idx = self.get_idx(x, y);
        self.particles[idx]
    }

    pub fn toggle_modified_state(&mut self) -> bool {
        self.modified_state = !self.modified_state;
        self.modified_state
    }

    pub fn add_heat(&mut self, x: i32, y: i32, heat: f32) {
        if x < 0 || x > self.width - 1 || y < 0 || y > self.height - 1 {
            return;
        }
        let idx = self.get_idx(x, y);
        self.particles[idx].temperature =
            (self.particles[idx].temperature + heat).clamp(-200., 9275.)
    }

    pub fn is_modified(&self) -> bool {
        self.modified_state
    }

    pub fn set_pressure(&mut self, x: i32, y: i32, pressure: f32) {
        if x < 0 || x > self.width - 1 || y < 0 || y > self.height - 1 {
            return;
        }
        let idx = self.get_idx(x, y);
        self.environment[idx].pressure = pressure;
    }

    pub fn set_temperature(&mut self, x: i32, y: i32, temperature: f32) {
        if x < 0 || x > self.width - 1 || y < 0 || y > self.height - 1 {
            return;
        }

        let idx = self.get_idx(x, y);
        self.environment[idx].ambient_temperature = temperature;
    }

    pub fn get_particle_count(&self) -> usize {
        self.particles
            .iter()
            .filter(|p| p.get_variant() != Variant::Empty && p.get_variant() != Variant::Wall)
            .count()
    }

    pub fn erase_indestructible(&mut self, x: i32, y: i32) {
        // gives ability to erase immutable particles
        let idx = self.get_idx(x, y);
        let particle = self.particles[idx];
        if particle.variant_type.has_flag(variant_type::FLAG_IMMUTABLE) {
            self.particles[idx] = Particle::default();
        }
    }

    pub fn set_particle(&mut self, x: i32, y: i32, variant: Variant) {
        if x < 0 || x > self.width - 1 || y < 0 || y > self.height - 1 {
            return;
        }

        // if the particle is already set to the same variant, don't do anything
        if self.get_particle(x, y).get_variant() == variant {
            return;
        }

        // if the particle is already a wall, don't do anything
        if self.get_particle(x, y).get_variant() == Variant::Wall {
            return;
        }

        let idx = self.get_idx(x, y);
        self.particles[idx] = Particle::new(*VariantType::from_variant(variant), 0, 0);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_world_set() {
        let world = World::new(100, 100);
        assert_eq!(world.get_particle(0, 0).get_variant(), Variant::Empty);
    }
}
