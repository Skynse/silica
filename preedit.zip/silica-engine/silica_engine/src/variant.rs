// filepath: c:\Users\austi\projects\silica\silica-engine\silica_engine\src\variant.rs
use std::fmt::Display;

use crate::element_registry::registry;
pub use crate::{api::API, element_registry, particle::Particle, variant_type::VariantProperty};
use serde::{Deserialize, Serialize};

#[repr(u8)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Variant {
    Empty = 0,
    Wall = 1,
    Sand = 2,
    Glass = 17,
    Water = 3,
    Fire = 4,
    Smoke = 5,
    Salt = 6,
    SaltWater = 7,

    // CHEM
    OXGN = 8,
    HYGN = 9,
    HELM = 10,
    CARB = 11,
    NITR = 12,
    IRON = 13,

    // COMPOUNDS
    CO2 = 14, //gas

    //GASES
    WTVP = 15, //water vapor

    //LIFE
    GOL = 16, //game of life

    //MECHANICS
    WindGenerator = 18, // wind generator
}

impl Display for Variant {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{} ({})", self.get_name(), *self as u8)
    }
}

impl Variant {
    pub fn from_u8(n: u8) -> Variant {
        match n {
            0 => Variant::Empty,
            1 => Variant::Wall,
            2 => Variant::Sand,
            3 => Variant::Water,
            4 => Variant::Fire,
            5 => Variant::Smoke,
            6 => Variant::Salt,
            7 => Variant::SaltWater,
            8 => Variant::OXGN,
            9 => Variant::HYGN,
            10 => Variant::HELM,
            11 => Variant::CARB,
            12 => Variant::NITR,
            13 => Variant::IRON,
            14 => Variant::CO2,
            15 => Variant::WTVP,
            16 => Variant::GOL,
            17 => Variant::Glass,
            18 => Variant::WindGenerator,
            _ => Variant::Empty,
        }
    }

    pub fn is_empty(&self) -> bool {
        *self == Variant::Empty
    }

    pub fn update(&self, particle: Particle, api: API) -> bool {
        registry().update_particle(particle, api)
    }
    pub fn get_name(&self) -> &'static str {
        match self {
            Variant::Empty => "EMPT",
            Variant::Wall => "WALL",
            Variant::Sand => "SAND",
            Variant::Water => "WATR",
            Variant::Fire => "FIRE",
            Variant::Smoke => "SMOK",
            Variant::Salt => "SALT",
            Variant::SaltWater => "SWTR",
            Variant::CARB => "CRBN",
            Variant::IRON => "IRON",
            Variant::OXGN => "OXYG",
            Variant::HYGN => "HYDR",
            Variant::HELM => "HELM",
            Variant::NITR => "NITR",
            Variant::CO2 => "CO2",
            Variant::WTVP => "STM",
            Variant::GOL => "GOL",
            Variant::Glass => "GLAS",
            Variant::WindGenerator => "WIND",
        }
    }
}
