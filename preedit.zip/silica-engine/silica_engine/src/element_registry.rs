use std::collections::HashMap;
use std::sync::OnceLock;

use crate::{
    api::API,
    colors::*,
    particle::Particle,
    variant::Variant,
    variant_type::{
        ParticleColor, VariantProperty, VariantType, FLAG_ALIVE, FLAG_BURNS, FLAG_IGNITES,
        FLAG_IMMUTABLE,
    },
    wind::Wind,
};

type UpdateFunction = fn(Particle, API) -> bool;

pub struct ElementRegistry {
    elements: HashMap<Variant, ElementDefinition>,
}

pub struct ElementDefinition {
    pub variant: Variant,
    pub variant_type: VariantType,
    pub update_fn: UpdateFunction,
}

static REGISTRY: OnceLock<ElementRegistry> = OnceLock::new();

pub fn registry() -> &'static ElementRegistry {
    REGISTRY.get_or_init(|| ElementRegistry::new())
}

impl ElementRegistry {
    fn new() -> Self {
        let mut registry = ElementRegistry {
            elements: HashMap::new(),
        };

        // Register all built-in elements
        registry.register_builtin_elements();

        registry
    }

    fn register_builtin_elements(&mut self) {
        // Register Empty
        self.register_element(
            Variant::Empty,
            "EMPT",
            EMPTY_COLOR,
            0,
            0,
            VariantProperty::Solid,
            0,
            22.0,
            update_empty,
        );

        // Register Empty with life flag
        self.register_element_with_variant(
            Variant::Empty,
            "EMPT_L",
            EMPTY_COLOR,
            0,
            0,
            VariantProperty::Solid,
            FLAG_ALIVE,
            22.0,
            update_empty,
        );

        // Register Wall
        self.register_element(
            Variant::Wall,
            "WALL",
            WALL_COLOR,
            255,
            0,
            VariantProperty::Solid,
            FLAG_IMMUTABLE,
            22.0,
            update_wall,
        );

        // Register Sand
        self.register_element(
            Variant::Sand,
            "SAND",
            SAND_COLOR,
            64,
            0,
            VariantProperty::Powder,
            0,
            22.0,
            update_sand,
        );

        // Register Water
        self.register_element(
            Variant::Water,
            "WATR",
            WATER_COLOR,
            32,
            0,
            VariantProperty::Liquid,
            0,
            22.0,
            update_water,
        );

        // Register Fire
        self.register_element(
            Variant::Fire,
            "FIRE",
            FIRE_COLOR,
            64,
            16,
            VariantProperty::Gas,
            FLAG_BURNS,
            422.0,
            update_fire,
        );

        // Register Smoke
        self.register_element(
            Variant::Smoke,
            "SMOK",
            SMOKE_COLOR,
            1,
            64,
            VariantProperty::Gas,
            0,
            22.0,
            update_smoke,
        );

        // Register Salt
        self.register_element(
            Variant::Salt,
            "SALT",
            SALT_COLOR,
            1,
            0,
            VariantProperty::Powder,
            0,
            22.0,
            update_salt,
        );

        // Register Salt Water
        self.register_element(
            Variant::SaltWater,
            "SWTR",
            SALT_WATER_COLOR,
            38,
            0,
            VariantProperty::Liquid,
            0,
            22.0,
            update_salt_water,
        );

        // Register Oxygen
        self.register_element(
            Variant::OXGN,
            "OXYG",
            OXYGEN_COLOR,
            0,
            0,
            VariantProperty::Gas,
            FLAG_BURNS | FLAG_IGNITES,
            22.0,
            update_oxygen,
        );

        // Register Hydrogen
        self.register_element(
            Variant::HYGN,
            "HYDR",
            HYDROGEN_COLOR,
            0,
            0,
            VariantProperty::Gas,
            FLAG_BURNS | FLAG_IGNITES,
            22.0,
            update_hydrogen,
        );

        // Register Helium
        self.register_element(
            Variant::HELM,
            "HELM",
            HELIUM_COLOR,
            0,
            0,
            VariantProperty::Gas,
            0,
            22.0,
            update_helium,
        );

        // Register Carbon
        self.register_element(
            Variant::CARB,
            "CRBN",
            CARBON_COLOR,
            0,
            0,
            VariantProperty::Powder,
            0,
            22.0,
            update_carbon,
        );

        // Register Nitrogen
        self.register_element(
            Variant::NITR,
            "NITR",
            NITROGEN_COLOR,
            0,
            0,
            VariantProperty::Gas,
            0,
            22.0,
            update_nitrogen,
        );

        // Register Iron
        self.register_element(
            Variant::IRON,
            "IRON",
            IRON_COLOR,
            0,
            0,
            VariantProperty::Solid,
            0,
            22.0,
            update_iron,
        );

        // Register CO2
        self.register_element(
            Variant::CO2,
            "CO2",
            CO2_COLOR,
            0,
            0,
            VariantProperty::Gas,
            0,
            22.0,
            update_co2,
        );

        // Register Water Vapor
        self.register_element(
            Variant::WTVP,
            "STM",
            STEAM_COLOR,
            0,
            0,
            VariantProperty::Gas,
            0,
            22.0,
            update_wtvp,
        );

        // Register Game of Life
        self.register_element(
            Variant::GOL,
            "GOL",
            ParticleColor {
                r: 255,
                g: 255,
                b: 255,
                a: 255,
            },
            0,
            16,
            VariantProperty::Solid,
            0,
            22.0,
            update_gol,
        );

        // Register Glass
        self.register_element(
            Variant::Glass,
            "GLAS",
            GLASS_COLOR,
            0,
            0,
            VariantProperty::Solid,
            0,
            22.0,
            update_glass,
        );

        // Register Wind Generator
        self.register_element(
            Variant::WindGenerator,
            "WIND",
            WIND_GENERATOR_COLOR,
            255, // Maximum strength
            0,
            VariantProperty::Solid,
            FLAG_IMMUTABLE, // Wind generator is immovable
            22.0,
            update_wind_generator,
        );
    }

    pub fn register_element(
        &mut self,
        variant: Variant,
        name: &'static str,
        color: ParticleColor,
        weight: u8,
        strength: u8,
        property: VariantProperty,
        flags: u8,
        base_temp: f32,
        update_fn: UpdateFunction,
    ) {
        let variant_type = VariantType {
            weight,
            color,
            strength,
            source_variant: variant,
            variant_property: property,
            flags,
            base_temperature: base_temp,
        };

        let definition = ElementDefinition {
            variant,
            variant_type,
            update_fn,
        };

        self.elements.insert(variant, definition);
    }

    // Special case for elements that share the same variant but have different properties
    // (like EMPTY and EMPTY_L)
    pub fn register_element_with_variant(
        &mut self,
        variant: Variant,
        name: &'static str,
        color: ParticleColor,
        weight: u8,
        strength: u8,
        property: VariantProperty,
        flags: u8,
        base_temp: f32,
        update_fn: UpdateFunction,
    ) -> Variant {
        let variant_type = VariantType {
            weight,
            color,
            strength,
            source_variant: variant,
            variant_property: property,
            flags,
            base_temperature: base_temp,
        };

        let definition = ElementDefinition {
            variant,
            variant_type,
            update_fn,
        };

        // For now, we just add it with a key that won't be used normally.
        // We'll need to handle this special case separately when needed.
        self.elements.insert(variant, definition);
        variant
    }

    pub fn get_variant_type(&self, variant: Variant) -> &VariantType {
        match self.elements.get(&variant) {
            Some(def) => &def.variant_type,
            None => panic!("Unknown variant: {:?}", variant),
        }
    }

    pub fn get_color(&self, variant: Variant) -> ParticleColor {
        self.get_variant_type(variant).color
    }

    pub fn get_variant_from_color(&self, color: &ParticleColor) -> Variant {
        // Find the variant with the closest color match
        // This is a naive implementation - you might want to optimize this
        let mut closest_variant = Variant::Empty;
        let mut min_distance = f32::MAX;

        for (variant, def) in &self.elements {
            let distance = def.variant_type.color.distance(color);
            if distance < min_distance {
                min_distance = distance;
                closest_variant = *variant;
            }
        }

        closest_variant
    }

    pub fn update_particle(&self, particle: Particle, api: API) -> bool {
        let variant = particle.get_variant();
        match self.elements.get(&variant) {
            Some(def) => (def.update_fn)(particle, api),
            None => false,
        }
    }
}

// All the update functions moved from variant.rs
fn update_empty(_particle: Particle, mut api: API) -> bool {
    let mut alive_nbrs = 0;
    if api.get(0, 1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(0, -1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(1, 0).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(-1, 0).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(1, 1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(-1, -1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(1, -1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(-1, 1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if alive_nbrs == 3 {
        api.set(
            0,
            0,
            Particle::new(registry().get_variant_type(Variant::GOL).clone(), 0, 0),
        );
        return true;
    }
    false
}

fn update_wall(_particle: Particle, _api: API) -> bool {
    false
}

fn update_sand(particle: Particle, mut api: API) -> bool {
    if particle.temperature > 1700. {
        api.set(
            0,
            0,
            Particle {
                variant_type: registry().get_variant_type(Variant::Glass).clone(),
                ..particle
            },
        );
        return true;
    }
    false
}

fn update_glass(_particle: Particle, _api: API) -> bool {
    true
}

fn update_salt(particle: Particle, mut api: API) -> bool {
    // swap down with water if water above
    let top = api.get(0, -1);
    let bottom = api.get(0, 1);

    if top.get_variant() == Variant::Water && bottom.get_variant() == Variant::Empty {
        api.set(
            0,
            -1,
            Particle {
                variant_type: registry().get_variant_type(Variant::Empty).clone(),
                ..top
            },
        );
        api.set(
            0,
            1,
            Particle {
                variant_type: registry().get_variant_type(Variant::SaltWater).clone(),
                ..particle
            },
        );
        return true;
    }

    false
}

fn update_salt_water(_particle: Particle, mut _api: API) -> bool {
    // swap down with water if water above\
    // if temp > 102, then turn into one part steam, one part salt
    let top = _api.get(0, -1);
    let bottom = _api.get(0, 1);

    if _particle.temperature > 102. {
        // turn into one part steam, one part salt
        // check to see if there's room for steam AND salt, then split
        // otherwise, just turn into salt
        if top.get_variant() == Variant::Empty && bottom.get_variant() == Variant::Empty {
            _api.set(
                0,
                -1,
                Particle {
                    variant_type: registry().get_variant_type(Variant::WTVP).clone(),
                    .._particle
                },
            );
            _api.set(
                0,
                1,
                Particle {
                    variant_type: registry().get_variant_type(Variant::Salt).clone(),
                    .._particle
                },
            );
        } else {
            _api.set(
                0,
                0,
                Particle {
                    variant_type: registry().get_variant_type(Variant::Salt).clone(),
                    .._particle
                },
            );
        }

        return true;
    }
    false
}

fn update_fire(mut particle: Particle, mut api: API) -> bool {
    if api.once_per(50) && particle.dissolve_to(registry().get_variant_type(Variant::Empty).clone())
    {
        api.set(
            0,
            0,
            Particle {
                variant_type: registry().get_variant_type(Variant::Smoke).clone(),
                ..particle
            },
        );
        return true;
    }

    api.world.set_temperature(api.x, api.y, 800.);
    false
}

fn update_water(particle: Particle, mut api: API) -> bool {
    let _dx = api.rand_dir();
    let _nbr = api.get(0, 1);

    if particle.temperature > 100. {
        api.set(
            0,
            0,
            Particle {
                variant_type: registry().get_variant_type(Variant::WTVP).clone(),
                ..particle
            },
        );
        return true;
    }

    false
}

fn update_smoke(mut particle: Particle, mut api: API) -> bool {
    if api.once_in(10) && particle.dissolve_to(registry().get_variant_type(Variant::Empty).clone())
    {
        api.set(0, 0, Particle::default());
        return true;
    }

    false
}

fn update_carbon(mut particle: Particle, mut api: API) -> bool {
    if api.once_in(10) && particle.dissolve_to(registry().get_variant_type(Variant::Empty).clone())
    {
        api.set(0, 0, Particle::default());
        return false;
    }
    false
}

fn update_iron(mut particle: Particle, mut api: API) -> bool {
    if api.once_in(10) && particle.dissolve_to(registry().get_variant_type(Variant::Empty).clone())
    {
        api.set(0, 0, Particle::default());
        return false;
    }
    false
}

fn update_oxygen(particle: Particle, mut api: API) -> bool {
    // check surrounding environment pressure
    // also check temperature

    // if pressure is high, temp is high, and particle is right next to hydrogen, then, combine into water

    let left = api.get(-1, 0);
    let right = api.get(1, 0);
    let up = api.get(0, -1);
    let down = api.get(0, 1);

    let mut nbrs = vec![left, right, up, down];

    nbrs.sort_by(|a, b| a.temperature.partial_cmp(&b.temperature).unwrap());

    let mut nbr = nbrs[0];

    if nbr.get_variant() == Variant::HYGN
        && nbr.dissolve_to(registry().get_variant_type(Variant::Water).clone())
    {
        {
            api.set(0, 0, nbr);
            api.set(0, 1, particle);
        }
    }

    // if temperature high enough, burn into fire
    if api.world.get_temperature(api.x, api.y) > 100. {
        api.set(
            0,
            0,
            Particle {
                variant_type: registry().get_variant_type(Variant::Fire).clone(),
                ..particle
            },
        );
        return true;
    }

    false
}

fn update_wtvp(particle: Particle, mut api: API) -> bool {
    if particle.temperature < 100. && particle.temperature > 0. {
        api.set(
            0,
            0,
            Particle {
                variant_type: registry().get_variant_type(Variant::Water).clone(),
                ..particle
            },
        );
        return true;
    }

    false
}

fn update_gol(particle: Particle, mut api: API) -> bool {
    let mut alive_nbrs: u32 = 0;

    if api.get(0, 1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(0, -1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(1, 0).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(-1, 0).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(1, 1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(-1, -1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(1, -1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if api.get(-1, 1).get_variant() == Variant::GOL {
        alive_nbrs += 1;
    }

    if alive_nbrs < 2 || alive_nbrs > 3 {
        api.set(
            0,
            0,
            Particle {
                variant_type: registry().get_variant_type(Variant::Empty).clone(),

                ..particle
            },
        );
    }

    // get self temperature and die
    if particle.temperature > 100. {
        api.set(
            0,
            0,
            Particle {
                variant_type: registry().get_variant_type(Variant::Sand).clone(),
                ..particle
            },
        );
    }
    true
}

fn update_hydrogen(mut particle: Particle, mut api: API) -> bool {
    if api.once_in(10) && particle.dissolve_to(registry().get_variant_type(Variant::Empty).clone())
    {
        api.set(0, 0, Particle::default());
        return false;
    }
    false
}

fn update_helium(mut particle: Particle, mut api: API) -> bool {
    if api.once_in(10) && particle.dissolve_to(registry().get_variant_type(Variant::Empty).clone())
    {
        api.set(0, 0, Particle::default());
        return false;
    }
    false
}

fn update_nitrogen(mut particle: Particle, mut api: API) -> bool {
    if api.once_in(10) && particle.dissolve_to(registry().get_variant_type(Variant::Empty).clone())
    {
        api.set(0, 0, Particle::default());
        return false;
    }
    false
}

fn update_co2(mut particle: Particle, mut api: API) -> bool {
    if api.once_in(10) && particle.dissolve_to(registry().get_variant_type(Variant::Empty).clone())
    {
        api.set(0, 0, Particle::default());
        return false;
    }
    false
}

// Wind generator implementation
fn update_wind_generator(_particle: Particle, mut api: API) -> bool {
    // Wind generator creates wind in a specific direction
    // For this implementation, we'll generate wind to the right

    // Parameters for wind generation
    let direction_x = 5; // Wind direction x component
    let direction_y = 0; // Wind direction y component (0 for horizontal wind)

    // Get the current position
    let x = api.x;
    let y = api.y;

    // Generate wind in multiple positions in front of the generator for better effect
    // This creates a stream of wind that pushes particles
    for i in 1..10 {
        // Create wind with decreasing strength as it gets further from the generator
        let strength_x = (direction_x as f32 * (1.0 - i as f32 * 0.08)).max(1.0) as i8;

        // Create wind in front of the generator with distance i
        api.add_wind(x + i, y, strength_x, direction_y);

        // Also create wind slightly above and below for a wider effect
        if i > 1 {
            api.add_wind(x + i, y - 1, strength_x, direction_y);
            api.add_wind(x + i, y + 1, strength_x, direction_y);
        }

        // For wider spread further from the generator
        if i > 3 {
            api.add_wind(x + i, y - 2, strength_x / 2, direction_y);
            api.add_wind(x + i, y + 2, strength_x / 2, direction_y);
        }
    }

    // Wind generator stays in place
    false
}
